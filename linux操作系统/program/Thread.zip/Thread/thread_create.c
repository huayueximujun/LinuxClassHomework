//thread_create.c	

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

void print_ids (const char *s)
{
    pid_t       pid;
    pthread_t   tid;
    pid = getpid();
    tid = pthread_self();
 
    printf("%s pid %u tid %u (0x%x)\n", s,\
        (unsigned int)pid,(unsigned int)tid,\
        (unsigned int)tid);
}

void *thread_func(void *arg)
{
    print_ids("new thread: ");
    printf("thread param is :%d\n",*(int *)arg);
    return NULL;
}
int main(void)
{

    int err;
    pthread_t newtid;
    int myarg;
    myarg=1;
    err = pthread_create (&newtid, NULL, thread_func, &myarg);
    if (err != 0)
    {
        perror("create thread error");
        exit(1);
    }
    print_ids("main thread:");
    sleep(1);
    exit(0);
}
