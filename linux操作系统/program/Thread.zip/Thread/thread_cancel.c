//thread_cancel.c

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>

void *thread1(void *arg) {
    int i, err, j;
    err = pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
    if (err != 0) {
        perror("Thread1 pthread_setcancelstate failed");
        exit(EXIT_FAILURE);
    }
    err = pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, NULL);
    if (err != 0) {
        perror("Thread1 pthread_setcanceltype failed");
        exit(EXIT_FAILURE);
    }
    printf("thread1 is running\n");
    for(i = 0; i < 5; i++) {
        printf("Thread1 is still running (%d)...\n", i);
        sleep(1);
    }
    pthread_exit((void *)2);
}

void *thread2(void *arg) {
    int i, err, j;
    err = pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);
    if (err != 0) {
        perror("Thread2 pthread_setcancelstate failed");
        exit(EXIT_FAILURE);
    }
    err = pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, NULL);
    if (err != 0) {
        perror("Thread2 pthread_setcanceltype failed");
        exit(EXIT_FAILURE);
    }
    printf("thread2 is running\n");
    for(i = 0; i < 5; i++) {
        printf("Thread2 is still running (%d)...\n", i);
        sleep(1);
    }
    pthread_exit((void *)2);
}

int main() {
    int err;
    pthread_t tid1,tid2;
    void *thread_result;

    err = pthread_create(&tid1, NULL, thread1, NULL);
    if (err != 0) {
        perror("Thread1 creation failed");
        exit(EXIT_FAILURE);
    }
    err = pthread_create(&tid2, NULL, thread2, NULL);
    if (err != 0) {
        perror("Thread2 creation failed");
        exit(EXIT_FAILURE);
    }
    sleep(2);
    
    printf("Cancelling thread1 ...\n");
    err = pthread_cancel(tid1);
    if (err != 0) {
        perror("Thread1 cancelation failed");
        exit(EXIT_FAILURE);
    }
    err = pthread_cancel(tid2);
    if (err != 0) {
        perror("Thread2 cancelation failed");
        exit(EXIT_FAILURE);
    }
    printf("Waiting for thread2 to finish...\n");
    err = pthread_join(tid1, &thread_result);
    if (err != 0) {
        perror("Thread1 join failed");
        exit(EXIT_FAILURE);
    }
    printf("The exit code of thread1 :%d\n",(int)thread_result);
    err = pthread_join(tid2, &thread_result);
    if (err != 0) {
        perror("Thread2 join failed");
        exit(EXIT_FAILURE);
    }
    printf("The exit code of thread2 :%d\n",(int)thread_result);

    exit(EXIT_SUCCESS);
}
