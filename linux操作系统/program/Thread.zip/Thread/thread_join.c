//thread_join.c

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void * thread1(void *arg)
{
    printf("thread1 returning\n");
    return ((void *)1);
}

void * thread2(void *arg)
{
    printf("thread2 exiting\n");
    pthread_exit ((void *)2);
}

int main(void)
{
    int err;
    pthread_t tid1,tid2;
    void *tret;

    err = pthread_create (&tid1, NULL, thread1, NULL);
    if (err != 0)
    {
        perror("create thread1 error");
        exit(1);
    }
    err = pthread_create (&tid2, NULL, thread2, NULL);
    if (err != 0)
    {
        perror("create thread2 error");
        exit(1);
    }
    err = pthread_join(tid1, &tret);
    if (err != 0)
    {
        perror("join thread1 error");
        exit(1);
    }
    printf("The exit code of thread1 :%d\n",(int)tret);
    err = pthread_join(tid2, &tret);
    if (err != 0)
    {
        perror("join thread2 error");
        exit(1);
    }
    printf("The exit code of thread2 :%d\n",(int)tret);
    exit(0);
}
